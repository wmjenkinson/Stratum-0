/*
 * stratum1_server.c
 *
 * Created: 17/09/2015 15:31:30
 *  Author: wmjen
 */ 
#include "asf.h"
#include "Darkness_Kernel/kernel architecture.h"
#include "Darkness_Kernel/interrupt_service_core.h"
#include "Darkness_Kernel/stratum_server/stratum1_server.h"

volatile int GeneralPPS_Failure;
long long test_historical; int test_cyrstal;


struct stratum stratum_server_object;

const short TERMINATE_ALGORITHM = 0x9999;
# define rounddown 0.5


#include "Darkness_Kernel/exception gateway.h"
#include "Darkness_Kernel/deferred_service_busy.h"
#include "Darkness_Kernel/deferred service core.h"

struct identifier * stratum_bridge_id;

void NMI_Bridge(int Arguments);
void NMI_Bridge(int Arguments){
	
	extern struct task_ctrl_obj * stratum_task;
	extern unsigned char internal_kernel_insert_task(struct task_ctrl_obj * tcb);
	
	if(stratum_task->task_status == DORMANT){
		internal_kernel_insert_task(stratum_task);
	}
}
__attribute__((optimize("-O2")))void stratum_algorithm(void){
	

	static int ppsError = 0; 
	static int previousErrors = 0;
	
	struct stratum1_packet * irq_stratum_stratum_object;
	
	
	for(int i = 0; i != stratum_server_object.nr_registered; i++){
		
		irq_stratum_stratum_object = stratum_server_object.start; stratum_server_object.start = stratum_server_object.start->next;
		
		// Monitor Performance of DAS Algorithm for test purposes
		irq_stratum_stratum_object->measured_frequency = irq_stratum_stratum_object->sample_counter; 
		irq_stratum_stratum_object->sample_counter = 0;
		
		irq_stratum_stratum_object->error_derivation = tc_read_tc(&AVR32_TC, irq_stratum_stratum_object->mcu_clock);
		
		// Detect GPS Communications Failure and ignore error
		if((irq_stratum_stratum_object->measured_frequency < (irq_stratum_stratum_object->target_frequency - 10)) || (irq_stratum_stratum_object->measured_frequency > (irq_stratum_stratum_object->target_frequency + 10))){
			
			irq_stratum_stratum_object->measured_frequency = irq_stratum_stratum_object->target_frequency; 
			ppsError = 4;
		}
		
		
		// Correct for Pulse Per Second Telecommunications Error
		if(ppsError != 0){
			ppsError--;
			if(ppsError == 0){
				irq_stratum_stratum_object->errors = previousErrors;
			}
		}
		else{
			previousErrors = irq_stratum_stratum_object->errors;
		}
	}
	api_invoke(stratum_bridge_id, 0);
}

/*!
 * \brief Interrupt handler of the External interrupt line "1" assigned to the NMI exception.
 *
 * \note This function is not static because it is referenced outside
 * (in exception.S for GCC and in exception.s82 for IAR).
 */
#if __GNUC__
__attribute__((naked))
#elif __ICCAVR32__
#pragma shadow_registers = full
#endif
void eic_nmi_handler(void)
{	
	// exception prologue, save r0-r12, lr and handle rtos pre-emtive 
	exception_prologue(NMI);
	
	if(stratum_server_object.nr_registered != 0){
		stratum_algorithm(); // Run Stratum Algorithm on all Clocks Registered requesting Stratum-1 Support
	}
	
	// clear NMI - Non-Maskable-Interrupt
	eic_clear_interrupt_line(&AVR32_EIC, EXT_NMI);
	
	// exception epilogue, handle dsr's
	exception_epilogue(NMI);
}

__attribute__((optimize("-O2")))unsigned short implement_stratum(struct stratum1_packet * setup){ 
	
	setup->sample_counter++;

	// Implement Drift Table Correction
	int offset = 0;
	int j = 0;
	
		//Bool test = !stratum_object->table;
		while(setup->drift_table[j] != TERMINATE_ALGORITHM){ 					// begin looping through the offset table preforming
			
			if(setup->drift_table[j] > 0){										// the required offset " + & -" to correct the timing
				if((setup->sample_counter % setup->drift_table[j]) == 0){
					offset++;
				}
			}
			else if(setup->drift_table[j] < 0){
				if((setup->sample_counter % setup->drift_table[j]) == 0){
					offset--;
				}
			}
			j++;
		}
	
	if(setup->tenth++ == 10){
		offset += setup->vulgar_table_static[0]; setup->tenth = 0; setup->hundredth++;
	}
	if(setup->hundredth == 10){
		offset += setup->vulgar_table_static[1]; setup->hundredth = 0; setup->thousandth++;
	}
	if(setup->thousandth == 10){
		offset += setup->vulgar_table_static[2]; setup->thousandth = 0; setup->goldie_locks++;
	}
	if(setup->goldie_locks == 100){
		offset += setup->vulgar_table_static[3]; setup->goldie_locks = 0;
	}
	
	return(setup->target_clock + offset);
}


struct stratum1_packet * configure_stratum1_clock(int clock, int clock_frequency, float clock_setting){
	
	// Be aware that the hold target value specifies the target error to hold during stratum processing 
	extern void * api_calloc(unsigned int, unsigned int);
	struct stratum1_packet * Stratum1_packet = api_calloc(1, sizeof(struct stratum1_packet));
	
	Stratum1_packet->drift_table[0] = TERMINATE_ALGORITHM;
	float finegrained = clock_setting - (int)clock_setting;
		
	// Calculate the floating point derivation for maximum coverage and accuracy 
	Stratum1_packet->vulgar_table_static[0] = (int)finegrained * 10; finegrained = finegrained * 10; finegrained -= (int)finegrained;
	Stratum1_packet->vulgar_table_static[1] = (int)finegrained * 10; finegrained = finegrained * 10; finegrained -= (int)finegrained;
	Stratum1_packet->vulgar_table_static[2] = (int)finegrained * 10; // Generate the offset table for decimal places
	
	
	Stratum1_packet->mcu_clock			= clock;						// i.e. 2578.125
	Stratum1_packet->target_frequency	= clock_frequency;				// Target Frequency, i.e. 1000 Hz
	Stratum1_packet->target_clock		= clock_setting;				// Major Target - i.e. 2578
	
	// Calculate Hold Value after locking on a suitable offset
	Stratum1_packet->hold_target = clock_setting / 2;
	
	// Initialization Period for calculating the mean offset required to lock and hold on a placement, then
	// using the Goldie locks location we will have the best solution to Crystal drift 
	Stratum1_packet->system_intialised_target = 10;
	
	// Add Stratum setting s to the system
	add_stratum_packet(Stratum1_packet);
	return(Stratum1_packet);
}

void add_stratum_packet( struct stratum1_packet * stratum1){
	
	enter_exception_section();
	
	if(stratum_server_object.nr_registered == 0){
		stratum_server_object.start = stratum1;
		stratum1->next = stratum1;
		stratum1->prev = stratum1;
	}
	else{
		stratum1->next = (struct stratum1_packet *)stratum_server_object.start;
		stratum1->prev = stratum_server_object.start->prev;
		stratum_server_object.start->prev->next = stratum1;
		stratum_server_object.start->prev = stratum1;
	}
	stratum_server_object.nr_registered++;
	
	leave_exception_section();
}

void remove_stratum_packet( struct stratum1_packet * stratum1){
	if( stratum_server_object.nr_registered == 1){
		stratum_server_object.nr_registered = 0;           // Unmark Priority Map
	}
	else
	{
		stratum_server_object.nr_registered--;
		if(stratum_server_object.start == stratum1){
			stratum_server_object.start = stratum1->next;
		}
		stratum1->prev->next = stratum1->next;
		stratum1->next->prev = stratum1->prev;
	}
}

unsigned char implementation_stratum1_rdy( struct stratum1_packet * stratum1, unsigned char test){
	if(stratum1->startup_synchronisation >= test){
		return(true); }
	else {
		return(false); }
}


__attribute__((optimize("-O2")))void Stratum_Core(void){
	
	
	struct stratum1_packet *  stratum_object = NULL;
	enter_critical_section();
	
	//! Structure holding the configuration parameters of the EIC module.
	eic_options_t eic_gps_pps_nmi;

	eic_gps_pps_nmi.eic_mode   = EIC_MODE_EDGE_TRIGGERED;	// Enable edge-triggered interrupt.
	eic_gps_pps_nmi.eic_edge   = AVR32_EIC_RISING_EDGE;		// Interrupt will trigger on rising edge.
	eic_gps_pps_nmi.eic_line   = EXT_NMI;					// Set the interrupt line number to Non-Maskable-Interrupt.
	
	eic_gps_pps_nmi.eic_filter = EIC_FILTER_ENABLED;
	eic_gps_pps_nmi.eic_async  = AVR32_EIC_SYNC;
	
	// Map the interrupt line to the GPIO pin with the right peripheral function.
	gpio_enable_module_pin(AVR32_EIC_EXTINT_8_PIN, AVR32_EIC_EXTINT_8_FUNCTION);
	
	// Init the EIC controller with the options // Enable the chosen lines and their corresponding interrupt feature.
	eic_init(&AVR32_EIC, &eic_gps_pps_nmi, 1); eic_enable_line(&AVR32_EIC, EXT_NMI); eic_enable_interrupt_line(&AVR32_EIC, EXT_NMI);

	
	stratum_bridge_id = register_deferal(NMI_Bridge);
	leave_critical_section();
	
	extern struct task_ctrl_obj * api_program(void(*task)(void), char const *, void *, unsigned int, unsigned char, unsigned char ); 
	int cyrstal_error = 0;
	
	while(true){
		
		api_suspend_task(api_ownID());
		
		for(int j = 0; j != stratum_server_object.nr_registered; j++){
			
			stratum_object = stratum_server_object.start; stratum_server_object.start = stratum_server_object.start->next;
			
			// Calculate the necessary offset table to correct for any characteristics variation
			cyrstal_error =  stratum_object->error_derivation - stratum_object->hold_target;
			
			test_cyrstal = cyrstal_error;
			
			// Runtime Goldie Locks Algorithm 
			if(cyrstal_error > 10){
				stratum_object->vulgar_table_static[3] += 1;
			}
			else if(cyrstal_error < 10){
				stratum_object->vulgar_table_static[3] -= 1;
			}
			
			int err_offset = 0, i = 0;
			
			
			// while an error exists or if variable i has not passed the limit barrier which in all but a select view cases is 3
			while(cyrstal_error != 0){

				err_offset = (stratum_object->target_frequency / cyrstal_error);							// obtain the first round pass
				
				stratum_object->drift_table[i++] = err_offset;
				
				cyrstal_error = (cyrstal_error - (stratum_object->target_frequency / err_offset));		// while an crystal_error exists continue finding drift values
			}stratum_object->drift_table[i] = TERMINATE_ALGORITHM;
		}
		
		if(stratum_object->startup_synchronisation != stratum_object->system_intialised_target){
	
			// Runtime Frequency Calibration
			if( stratum_object->measured_frequency < stratum_object->target_frequency){
				stratum_object->vulgar_table_static[0] -= 2;
			}
			else if( stratum_object->measured_frequency > stratum_object->target_frequency){
				stratum_object->vulgar_table_static[0] += 2;
			}
		}
		
		for(int j = 0; j != stratum_server_object.nr_registered; j++){
			
			stratum_object = stratum_server_object.start; stratum_server_object.start = stratum_server_object.start->next;
			
			if(stratum_object->startup_synchronisation == stratum_object->system_intialised_target){
				stratum_object->samples_aquired++;
				
				if(stratum_object->target_frequency != stratum_object->measured_frequency){
					stratum_object->errors++;
				}
			}
			else{
				// Lock & Hold Target Frequency when Achieved
				if(stratum_object->target_frequency == stratum_object->measured_frequency){
					stratum_object->startup_synchronisation++;
				}
				else{
					stratum_object->error = 0;
					stratum_object->startup_synchronisation = 0;
				}
			}
		}
	}
}